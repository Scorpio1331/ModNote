﻿using System;
using System.Windows.Forms;

namespace ModNote
{
    public partial class FrmModuleAdder : Form
    {        
        /// <summary>
        /// Initialize form, if manual button clicked return dialogresult = yes
        /// if import button clicked return dialog result ok
        /// </summary>
        public FrmModuleAdder()
        {
            InitializeComponent();
        }
    }
}
