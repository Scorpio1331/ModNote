﻿using System.Windows.Forms;

namespace ModNote
{
    public partial class FrmAssessmentType : Form
    {
        /// <summary>
        /// Initialize form, if user clicks Assignment return dialogresult Ok, if user
        /// clicks Test return dialogresult Yes and close form
        /// </summary>
        public FrmAssessmentType()
        {
            InitializeComponent();
        }
    }
}
